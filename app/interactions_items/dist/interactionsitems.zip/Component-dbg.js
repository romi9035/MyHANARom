sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("interactionsitems.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);